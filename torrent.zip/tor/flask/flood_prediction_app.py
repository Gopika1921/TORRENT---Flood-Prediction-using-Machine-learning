from flask import Flask,jsonify, render_template, request
import joblib
import numpy as np
import pandas as pd
#from sklearn.preprocessing import StandardScaler

app = Flask(__name__)

@app.route("/")
def home():
    return render_template('home.html')

@app.route('/predict')
def index():
    return render_template("index.html")

@app.route('/data_predict', methods=['POST','GET'])
def predict():
    cc = float(request.form['cc'])
    arf = float(request.form['arf'])
    jfr = float(request.form['jfr'])
    mmr = float(request.form['mmr'])
    jsr = float(request.form['jsr'])

    X = np.array([[cc, arf, jfr, mmr, jsr]])

    model_path = r'floods.sav'
    model = joblib.load(model_path)

    scaler_path = r'transform.sav'
    sc = joblib.load(scaler_path)

    # Load ML model
    flood_df = pd.read_excel('flood_dataset.xlsx')
    flood_df.drop(["Oct-Dec"],axis=1,inplace=True)
    X_core = flood_df.iloc[:,2:7].values
    sc.fit_transform(X_core)

    prediction = model.predict(sc.transform(X))
    output = prediction[0]

    #print(sc.transform(X))
          
    if(output==0):
        return render_template('noChance.html', prediction='No possibility of severe flood')
    else:
        return render_template('chance.html', prediction='possibility of severe flood')
    

if __name__ == "__main__":
    app.run(debug=True)
